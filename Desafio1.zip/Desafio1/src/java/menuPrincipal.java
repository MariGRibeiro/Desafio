
import br.Conexao.FabricaConexao;
import java.sql.Connection;
//import br.Erro.exception.ErroSistema;


/**
 *
 * @author Mari
 */
public class menuPrincipal {
    
    public static void main(String[] args){
        
        Connection connection = FabricaConexao.getConnection();
    }

}