/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.Conexao;
import br.Erro.ErroSistema;
import java.sql.Connection;
//import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class FabricaConexao {
    private static Connection conexao;
    private static final String URL_CONEXAO = "jdbc:mysql://localhost:3306/desafio";
    private  static  final String USUARIO = "root";
    private static final String SENHA = "";
    
    public static Connection getconexao()throws ErroSistema {
        if(conexao == null){
            try { 
                Class.forName("com.mysql.jdbc.Driver");
                conexao = DriverManager.getConnection(URL_CONEXAO,USUARIO,SENHA);
            }catch (SQLException ex){
                throw new  ErroSistema("Nao foi possivel conectar ao banco", ex);
            }catch (ClassNotFoundException ex){
                throw new ErroSistema("O drive do banco não foi encontrado",ex);
            }
        }
   return conexao;
 }
    public static void fecharconexao()throws ErroSistema{
        if(conexao != null){
            try {
                conexao.close();
                conexao = null;      
            } catch (SQLException ex) {
            throw new ErroSistema("Erro ao fechar conexão com o banco de dados", ex);
            }
        }    
    }

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}