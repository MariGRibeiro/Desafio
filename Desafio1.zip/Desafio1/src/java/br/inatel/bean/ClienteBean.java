package br.inatel.bean;


import br.inatel.dao.ClienteDAO;
import br.inatel.entidade.Cliente;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped

public class ClienteBean extends CrudBean<Cliente, ClienteDAO> {

    private ClienteDAO clienteDAO;
    
    @Override
    public ClienteDAO getDao() {
        if(clienteDAO == null){
            clienteDAO = new ClienteDAO();
        }
        return clienteDAO;
    }

    @Override
    public Cliente criarNovaEntidade() {
        return new Cliente();
    }

}
