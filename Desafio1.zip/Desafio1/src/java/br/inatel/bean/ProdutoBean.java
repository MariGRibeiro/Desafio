package br.inatel.bean;

import br.inatel.dao.ProdutoDAO;
import br.inatel.entidade.Produto;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Mari
 */
@ManagedBean
@SessionScoped

public class ProdutoBean extends CrudBean<Produto, ProdutoDAO> {
    
    private ProdutoDAO produtoDAO;
    
    @Override
    public ProdutoDAO getDao() {
        if(produtoDAO == null){
            produtoDAO = new ProdutoDAO();
        }
        return produtoDAO;
    }

    @Override
    public Produto criarNovaEntidade() {
        return new Produto();
    }

}
    
