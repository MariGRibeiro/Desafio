package br.inatel.dao;


import br.inatel.doces.util.FabricaConexao;
import br.inatel.entidade.Cliente;
import br.inatel.util.exception.ErroSistema;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ClienteDAO implements CrudDAO<Cliente>{
    
    @Override
    public void salvar(Cliente cliente) throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps;
            if(cliente.getId() == null){
                ps = conexao.prepareStatement("insert into `cliente` (`cpf`,`nome`,`endereco`,`email`,`senha`) VALUES (?,?,?,?,?)");
            } else {
                ps = conexao.prepareStatement("UPDATE cliente set cpf=?,  nome=?, endereco=?, email=?, senha=? where id=?");
                ps.setInt(6, cliente.getId());
            }
            ps.setString(1, cliente.getCpf());
            ps.setString(2, cliente.getNome());
            ps.setString(3, cliente.getEndereco());
            ps.setString(4, cliente.getEmail());
            ps.setString(5, cliente.getSenha());
      
            ps.execute();
            FabricaConexao.fecharConexao();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salvar!", ex);
        }
    }
    
    @Override
    public void deletar(Cliente cliente) throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps  = conexao.prepareStatement("delete from cliente where id = ?");
            ps.setInt(1, cliente.getId());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o Cliente!", ex);
        }
    }
    
    @Override
    public List<Cliente> listar() throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from cliente");
            ResultSet resultSet = ps.executeQuery();
            List<Cliente> clientes = new ArrayList<>();
            
            while(resultSet.next()){
                Cliente cliente = new Cliente();
                
                cliente.setId(resultSet.getInt("id"));
                cliente.setCpf(resultSet.getString("cpf"));
                cliente.setNome(resultSet.getString("nome"));
                cliente.setEndereco(resultSet.getString("endereco"));
                cliente.setEmail(resultSet.getString("email"));
                cliente.setSenha(resultSet.getString("senha"));
                
            
                clientes.add(cliente);
            }
            FabricaConexao.fecharConexao();
            return clientes;
            
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os Clientes!",ex);
        }
    }
}
