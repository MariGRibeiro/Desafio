package br.inatel.dao;

import br.inatel.doces.util.FabricaConexao;
import br.inatel.entidade.Produto;
import br.inatel.util.exception.ErroSistema;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mari
 */
public class ProdutoDAO implements CrudDAO<Produto>{
    
    @Override
    public void salvar(Produto produto) throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps;
            if(produto.getId() == null){
                ps = conexao.prepareStatement("insert into `doces` (`nome`,`preco`) VALUES (?,?)");
            } else {
                ps = conexao.prepareStatement("UPDATE doces set nome=?, preco=? where id=?");
                ps.setInt(3, produto.getId());
            }
            
            ps.setString(1, produto.getNome());
            ps.setString(2, produto.getPreco());
       
            ps.execute();
            FabricaConexao.fecharConexao();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salvar!", ex);
        }
    }
    
    @Override
    public void deletar(Produto produto) throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps  = conexao.prepareStatement("delete from doces where id = ?");
            ps.setInt(1, produto.getId());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o Produto!", ex);
        }
    }
    
    @Override
    public List<Produto> listar() throws ErroSistema{
        try {
            Connection conexao = FabricaConexao.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from doces");
            ResultSet resultSet = ps.executeQuery();
            List<Produto> produtos = new ArrayList<>();
            
            while(resultSet.next()){
                Produto produto = new Produto();
                
                produto.setId(resultSet.getInt("id"));
                produto.setNome(resultSet.getString("nome"));
                produto.setPreco(resultSet.getString("preco"));
     
                produtos.add(produto);
            }
            FabricaConexao.fecharConexao();
            return produtos;
            
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os Produtos!",ex);
        }
    }
}
